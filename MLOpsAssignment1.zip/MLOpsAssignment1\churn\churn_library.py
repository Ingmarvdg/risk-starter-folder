# library doc string
"""
This module contains functions to build a model for the prediction of churn
using bank client data.
"""

# import libraries
import os
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import RocCurveDisplay
from sklearn.base import BaseEstimator
from sklearn.inspection import permutation_importance
import numpy as np
import joblib

import matplotlib.pyplot as plt

special_columns = ["CLIENTNUM", "Attrition_Flag"]

cat_columns = [
    "Gender",
    "Education_Level",
    "Marital_Status",
    "Income_Category",
    "Card_Category",
]

quant_columns = [
    "Customer_Age",
    "Dependent_count",
    "Months_on_book",
    "Total_Relationship_Count",
    "Months_Inactive_12_mon",
    "Contacts_Count_12_mon",
    "Credit_Limit",
    "Total_Revolving_Bal",
    "Avg_Open_To_Buy",
    "Total_Amt_Chng_Q4_Q1",
    "Total_Trans_Amt",
    "Total_Trans_Ct",
    "Total_Ct_Chng_Q4_Q1",
    "Avg_Utilization_Ratio",
]


def _check_bank_data(client_df: pd.DataFrame) -> None:
    """
    Assert that the loaded data has the expected columns.

    input:
            client_df (DataFrame): the client dataframe
    output:
            None
    """

    for column in cat_columns:
        assert column in client_df.columns
        assert pd.api.types.is_object_dtype(client_df[column])

    for column in quant_columns:
        assert column in client_df.columns
        assert pd.api.types.is_numeric_dtype(client_df[column])


def load_bank_data(input_path: str) -> pd.DataFrame:
    """
    returns pre-processed dataframe for the csv found at pth

    input:
            path (str): a path to the csv
    output:
            client_df (dataframe): pandas dataframe
    """

    client_df = pd.read_csv(input_path)

    # drop unnamed columns
    client_df = client_df.loc[:, ~client_df.columns.str.contains('^Unnamed')]

    _check_bank_data(client_df)

    client_df["Attrition_Flag"] = client_df["Attrition_Flag"].apply(
        lambda val: 0 if val == "Existing Customer" else 1
    )

    return client_df


def perform_eda(client_df: pd.DataFrame, output_path: str) -> None:
    """
    perform eda on df and save figures to images folder
    input:
            df (pd.DataFrame): pandas dataframe.
            output_path (str): path to store images.

    output:
            None
    """

    # univariate quantitative plot.
    plt.figure(figsize=(10, 5))
    client_df["Customer_Age"].hist()

    plt.savefig(os.path.join(output_path, "eda_churn_age"))

    # univariate categorical plot.
    plt.figure(figsize=(10, 5))
    client_df["Marital_Status"].value_counts("normalize").plot(kind="bar")

    plt.savefig(os.path.join(output_path, "eda_churn_marital_status"))

    plt.figure(figsize=(10, 5))
    client_df.plot.scatter(
        x="Total_Trans_Amt",
        y="Total_Trans_Ct",
        c="Attrition_Flag")
    plt.savefig(os.path.join(output_path, "eda_churn_transactions"))


def encode_categorical(pd_df: pd.DataFrame) -> pd.DataFrame:
    """
    helper function to turn each categorical column into a new column with
    proportion of churn for each category - associated with cell 15 from the notebook

    input:
            pd_df (pd.DataFrame): pandas dataframe

    output:
            pd_df (pd.DataFrame): pandas dataframe with new columns for each
            value in categorical columns.
    """
    for colum in pd_df.columns:
        if pd.api.types.is_object_dtype(pd_df[colum]):
            # Get one hot encoding of columns B
            one_hot = pd.get_dummies(pd_df[colum], prefix=colum)
            # Drop column B as it is now encoded
            pd_df = pd_df.drop(colum, axis=1)
            # Join the encoded pd_df
            pd_df = pd_df.join(one_hot)

    return pd_df


def perform_feature_engineering(pd_df: pd.DataFrame,
                                feature_columns: list[str],
                                target_column: str,
                                random_state: int = 42):
    """
    Select feature columns as X and target column as Y.

    input:
              pd_df (pd.DataFrame): pandas dataframe.
              feature_columns (list[str]): list of columns to use as features.
              target_column (str): the target column

    output:
              x_train (pd.DataFrame): X training data
              x_test (pd.DataFrame): X testing data
              y_train (pd.DataFrame): y training data
              y_test (pd.DataFrame): y testing data
    """

    x_data = encode_categorical(pd_df[feature_columns])

    y_data = pd_df[[target_column]].values.ravel()

    return train_test_split(
        x_data,
        y_data,
        test_size=0.3,
        random_state=random_state)


def write_roc_image(model: BaseEstimator,
                    x_test: pd.DataFrame,
                    y_test: pd.DataFrame,
                    output_location: str = "./"):
    """
    creates and writes the roc curve image to given location
    input:
            model (BaseEstimator): the model to create roc curve image for
            x_test (pd.DataFrame): test features
            y_test (pd.DataFrame): test output
            output_location: (str): folder to write image to
    output:
            None
    """
    plt.figure(figsize=(15, 8))
    axis = plt.gca()

    RocCurveDisplay.from_estimator(model, x_test, y_test, ax=axis, alpha=0.8)

    plt.savefig(
        os.path.join(
            output_location,
            f"roc_curve_{model.__class__.__name__}"))


def write_feature_importance_image(model: BaseEstimator,
                                   x_test: pd.DataFrame,
                                   y_test: pd.DataFrame,
                                   output_location="./"):
    """
    creates and writes the feature importance image to given location
    input:
            model: the model to create feature importance image for
            x_test (pd.DataFrame): test features
            y_test (pd.DataFrame): test output
            output_location (str): folder to write image to
    output:
            None
    """
    # Calculate feature importances
    importances = permutation_importance(model, x_test, y_test)[
        "importances_mean"]
    # Sort feature importances in descending order
    indices = np.argsort(importances)[::-1]

    # Rearrange feature names so they match the sorted feature importances
    names = [x_test.columns[i] for i in indices]

    # Create plot
    plt.figure(figsize=(20, 5))

    # Create plot title
    plt.title("Feature Importance")
    plt.ylabel("Importance")

    # Add bars
    plt.bar(range(x_test.shape[1]), importances)

    # Add feature names as x-axis labels
    plt.xticks(range(x_test.shape[1]), names, rotation=90)

    plt.savefig(
        os.path.join(
            output_location,
            f"feature_importance_{model.__class__.__name__}"))


def save_model(model: BaseEstimator,
               output_location="./"):
    """
    save model to output location
    input:
            model (BaseEstimator): the model to save
            output_location (str): where to save the model
    output:
            None
    """
    joblib.dump(
        model,
        os.path.join(
            output_location,
            f"model_{model.__class__.__name__}.pkl"))


def train_model(x_train: pd.DataFrame,
                x_test: pd.DataFrame,
                y_train: pd.DataFrame,
                y_test: pd.DataFrame,
                model: BaseEstimator,
                output_location: str = "./"):
    """
    train, store model results: images + scores, and store models
    input:
              x_train (pd.DataFrame): X training data
              x_test (pd.DataFrame): X testing data
              y_train (pd.DataFrame): y training data
              y_test (pd.DataFrame): y testing data
              model (BaseEstimator): the model to train
    output:
              None
    """
    model.fit(x_train, y_train)

    if isinstance(model, GridSearchCV):
        best_estimator = model.best_estimator_
    else:
        best_estimator = model

    results_path = os.path.join(output_location, "results")
    models_path = os.path.join(output_location, "models")

    Path(results_path).mkdir(parents=True, exist_ok=True)
    Path(models_path).mkdir(parents=True, exist_ok=True)

    write_roc_image(
        best_estimator,
        x_test,
        y_test,
        output_location=results_path)
    write_feature_importance_image(
        best_estimator, x_test, y_test, output_location=results_path
    )
    save_model(best_estimator, output_location=models_path)
