"""
This module contains all the pytest configurations and fixtures.
"""

from pathlib import Path
import shutil
from sklearn.linear_model import LogisticRegression
import pytest
from churn.churn_library import load_bank_data


OUTPUT_PATH = "tests/.test_outputs/"
Path(OUTPUT_PATH).mkdir(parents=True, exist_ok=True)

@pytest.fixture(scope="session")
def output_resource_path():
    """Get output path."""
    return OUTPUT_PATH

@pytest.fixture(scope="function", autouse=True)
def clear_outputs():
    """Remove the output folder and recreate it."""
    shutil.rmtree(OUTPUT_PATH)
    Path(OUTPUT_PATH).mkdir(parents=True, exist_ok=True)


@pytest.fixture(scope="session")
def client_df():
    """Load dummy client df."""
    return load_bank_data("tests/resources/bank_data_good.csv")

@pytest.fixture(scope="session")
def model():
    """Load dummy model."""
    return LogisticRegression(solver='lbfgs', max_iter=20)
