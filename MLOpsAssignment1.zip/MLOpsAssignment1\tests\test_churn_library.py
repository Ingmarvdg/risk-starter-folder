from churn.churn_library import cat_columns, quant_columns, special_columns
import pandas as pd
import churn.churn_library as churn_library
import pytest
import os

def test_bank_data_good():
    """Assert if good data can be loaded."""
    data_path = "tests/resources/bank_data_good.csv"
    client_df = churn_library.load_bank_data(data_path)

    assert len(client_df) == 61
    assert set(client_df.columns) == set(cat_columns + quant_columns + special_columns)

def test_bank_data_missing_column():
    """Assert bad data can't be loaded."""
    with pytest.raises(AssertionError):
        data_path = "tests/resources/bank_data_bad.csv"
        churn_library.load_bank_data(data_path)

def test_perform_eda(client_df, output_resource_path):
    """Assert eda writes files to location."""
    
    churn_library.perform_eda(client_df, output_resource_path)

    assert len(os.listdir(output_resource_path)) == 3

def test_encode_categorical():
    """Assert after encode categorical correct columns still exist and output has expected length."""
    cat_1 = "a"
    cat_2 = "b"
    num_col = "num"
    obj_col = "obj"

    test_df_in = pd.DataFrame([[cat_1, 3], [cat_2, 4]], columns=[obj_col, num_col])

    test_df_out = churn_library.encode_categorical(test_df_in)

    assert num_col in test_df_out.columns
    assert obj_col not in test_df_out.columns
    assert len(test_df_out.columns) == len(test_df_in.columns) + 1

def test_perform_feature_engineering(client_df):
    """Assert that train and test dataframes have expected shapes."""

    output_dfs = churn_library.perform_feature_engineering(client_df,
                                                       [cat_columns[0], quant_columns[0]],
                                                       "Attrition_Flag"
                                                       )
    
    # check shape of each
    # train_x train_y lengths must be equal
    assert len(output_dfs[0]) == len(output_dfs[2])
    # test_x test_y lengths must be equal
    assert len(output_dfs[1]) == len(output_dfs[3])

    # total amount should be the same as the original df
    assert len(output_dfs[0]) + len(output_dfs[1]) == len(client_df)

    # both y's must have one column
    assert output_dfs[2].ndim == output_dfs[3].ndim == 1

def test_write_roc_image(model, output_resource_path):
    """Assert that function writes an image to output path."""
    x_values = pd.DataFrame([[1, 2], [2, 1]], columns=["A", "B"])
    y_values = [0, 1]

    model.fit(x_values, y_values)

    churn_library.write_roc_image(model, x_values, y_values, output_resource_path)

    assert len(os.listdir(output_resource_path)) == 1

def test_write_feature_importance_image(model, output_resource_path):
    """Assert that function writes an image to output path."""
    x_values = pd.DataFrame([[1, 2], [2, 1]], columns=["A", "B"])
    y_values = [0, 1]

    model.fit(x_values, y_values)

    churn_library.write_feature_importance_image(model, x_values, y_values, output_resource_path)

    assert len(os.listdir(output_resource_path)) == 1

def test_save_model(model, output_resource_path):
    """Assert that function writes a file to output path."""
    churn_library.save_model(model, output_resource_path)

    assert len(os.listdir(output_resource_path)) == 1

def test_train_model(model, output_resource_path):
    """Assert that function creates the expected directories."""
    x_values = pd.DataFrame([[1, 2], [2, 1]], columns=["A", "B"])
    y_values = [0, 1]

    churn_library.train_model(
        x_train = x_values,
        x_test = x_values,
        y_train = y_values,
        y_test = y_values,
        model = model,
        output_location = output_resource_path
        )

    assert len(os.listdir(output_resource_path)) == 2